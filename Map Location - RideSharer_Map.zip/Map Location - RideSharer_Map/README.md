As a part of Lyft's Virtual Experience, my task was to add a map with user's location and also check for the Location Permissions from the user.

![Lyft-Map](https://user-images.githubusercontent.com/98042082/187126381-5aebd09b-45b2-498b-a29f-03cca1f9f0e6.gif)
